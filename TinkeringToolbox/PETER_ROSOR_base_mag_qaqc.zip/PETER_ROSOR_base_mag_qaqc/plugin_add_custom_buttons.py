'''
THIS .PY FILE IS NOT THE SAME FOR ALL PLUGINS.
'''

def add_custom_buttons(guiz, plugin_dir):
    pass