Update this directory using maint_tools/vendor_array_api_extra.sh
