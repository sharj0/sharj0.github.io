def get():
    return ["_SELECT_FOLDER","_SELECT_LAYER", "_COMMENT", "_TOOLTIP"]